<?php
// include file koneksi
require '../koneksi.php';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $id = $_POST['id'];        
     $query = mysqli_query($con, "SELECT *
                FROM komentar a
                LEFT JOIN user b
                ON 
                a.id_user = b.id where a.id_wisata='$id' ");
       $response=array();
        $count = mysqli_num_rows($query);
          if($count>0) {

            $response["komentar"]=array();        
            while ($row=mysqli_fetch_array($query)){
                $data=array();

                $result=mysqli_query($con, "SELECT COUNT(*) total FROM komentar");
                $count=mysqli_fetch_assoc($result);

                $data["id"]=$row["id"];
                $data["nama"]=$row["nama"];
                $data["foto"]=$row["foto"];
                $data["pesan"]=$row["pesan"];
                $data["waktu"]=$row["waktu"];

                $response["total"]=$count['total'];                
                $response["msg"]=trim("success.");
                $response["code"]=200;
                $response["status"]=true;
                array_push($response["komentar"],$data);
                // print_r($data);
            }

            echo json_encode($response);

        } else {

            $response["msg"]=trim("not succes");
            $response["code"]=400;
            $response["status"]=false; 
            echo json_encode($response);

        }

} else {

            $response["msg"]=trim("failed get data");
            $response["code"]=401;
            $response["status"]=false; 
    echo json_encode($response);
}
