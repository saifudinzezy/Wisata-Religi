<?php
include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $id_wisata = $_POST['id_wisata'];
    $pesan = $_POST['pesan'];
    $waktu = $_POST['waktu'];

    //query untuk menambahkan data
    $query = "INSERT INTO komentar VALUES (null, '$id_wisata', '$id', '$pesan', '$waktu')";

    $exeQuery = mysqli_query($con, $query);

    echo ($exeQuery) ? json_encode(array('code' => 200, 'message' => 'Data berhasil disimpan')) : json_encode(array('code' => 400, 'message' => 'data gagal disimpan'));
} else {
    echo json_encode(array('code' => 404, 'message' => 'request tidak valid'));
}
