<?php
include '../koneksi.php';
$query = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $desk = $_POST['desk'];
    $pembicara = $_POST['pembicara'];
    $alamat = $_POST['alamat'];
    $duror = $_POST['duror'];
    $tanggal = $_POST['tanggal'];
    $waktu = $_POST['waktu'];

    $query = "UPDATE acara SET nama='$nama', desk='$desk', pembicara='$pembicara', alamat='$alamat',
        duror='$duror', tanggal='$tanggal', waktu='$waktu' WHERE id_acara='$id'";

    $exeQuery = mysqli_query($con, $query);

    echo ($exeQuery) ? json_encode(array('code' => 200, 'message' => 'Data berhasil ubah')) : json_encode(array('code' => 400, 'message' => 'data gagal diubah'));
} else {
    echo json_encode(array('code' => 404, 'message' => 'request tidak valid'));
}
