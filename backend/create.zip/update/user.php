<?php
//masukan koneksi
include '../koneksi.php';
define('SITE_ROOT', realpath(dirname(__DIR__)));
//buat untuk menaruh folder
$part = "/img/";
//buat var respone array untuk menampung nilai dari db
$response = array();

//buat var
$code = "";
$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    //ambil data dari user
    $id = $_POST['id'];
    $nama = str_replace("\"", "", $_POST['nama']);
    $tmp = str_replace("\"", "", $_POST['tmp']);
    $tgl = str_replace("\"", "", $_POST['tgl']);
    $pass = str_replace("\"", "", $_POST['pass']);
    $alamat = str_replace("\"", "", $_POST['alamat']);

    if (isset($_FILES['image'])) {
        //
        $hapus = str_replace("\"", "", $_POST['hapus']);
        //ambil nama dari file yang kita upload
        $nama_file = str_replace(" ", "_", $_FILES['image']['name']);
        // $nama_file = $_FILES['image']['name'];
        //untuk pindahkan gambar
        $destination = SITE_ROOT . $part . $nama_file;
        //cek jika ada file maka pindahkan dan bernilai true maka eksekusi
        if (move_uploaded_file($_FILES['image']['tmp_name'],  $destination)) {
            $image = str_replace(" ", "_", $_FILES['image']['name']);
            // $cek = $_POST['cek'];
            // nol berarti sampahnya belum dibersihkan
            $cek = 0;
            //masukan querynya
            //belum selesai
            $query = "UPDATE user SET nama='$nama', tmp_lahir='$tmp', tgl_lahir='$tgl',
                foto='$image', pass='$pass', alamat='$alamat' WHERE id = '$id'";

            $exeQuery = mysqli_query($con, $query);
            //buat pesan jika berhasil
            $kode = 200;
            // $pesan = "Berhasil Upload";
            $pesan = "Data berhasil diubah";
            unlink(__FILE__ . '/../../img/' . $hapus);
        } else {
            //buat pesan jika gagal
            $kode = 404;
            // $pesan = "Gagal Upload";
            $pesan = "Data gagal diubah";
        }
        //ambil nilinya dan taruh ke array untuk membuat jsonnya
        $res['code'] = $kode;
        $res['message'] = $pesan;
        //buat menjadi json
        echo json_encode($res);
    } else {
        //belum selesai			
        $query = "UPDATE user SET nama='$nama', tmp_lahir='$tmp', tgl_lahir='$tgl', pass='$pass', alamat='$alamat' WHERE id = '$id'";
        $exeQuery = mysqli_query($con, $query);

        echo ($exeQuery) ? json_encode(array('code' => 200, 'message' => 'data berhasil ubah')) : json_encode(array('code' => 404, 'message' => 'data gagal diubah'));
    }
} else {
    echo json_encode(array('code' => 101, 'message' => 'request tidak valid'));
}